import React from 'react';
import { Code, Smartphone, Globe, Zap, Shield, BarChart3 } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Code,
      title: 'Web Development',
      description: 'Custom web applications built with cutting-edge technologies for optimal performance and user experience.',
      features: ['React & Next.js', 'Full-Stack Solutions', 'API Integration']
    },
    {
      icon: Smartphone,
      title: 'Mobile Apps',
      description: 'Native and cross-platform mobile applications that deliver seamless experiences across all devices.',
      features: ['iOS & Android', 'React Native', 'Flutter Development']
    },
    {
      icon: Globe,
      title: 'Digital Strategy',
      description: 'Comprehensive digital transformation strategies to help your business thrive in the digital landscape.',
      features: ['Market Analysis', 'Growth Planning', 'Technology Roadmap']
    },
    {
      icon: Zap,
      title: 'Performance Optimization',
      description: 'Boost your application\'s speed and efficiency with our advanced optimization techniques.',
      features: ['Speed Enhancement', 'SEO Optimization', 'Core Web Vitals']
    },
    {
      icon: Shield,
      title: 'Cybersecurity',
      description: 'Protect your digital assets with enterprise-grade security solutions and best practices.',
      features: ['Security Audits', 'Data Protection', 'Compliance Management']
    },
    {
      icon: BarChart3,
      title: 'Analytics & Insights',
      description: 'Data-driven insights and analytics to help you make informed business decisions.',
      features: ['Custom Dashboards', 'Real-time Analytics', 'Performance Metrics']
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-600 rounded-full text-sm font-medium mb-4">
            Our Services
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Solutions That Drive
            <span className="block text-blue-600">Success</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We offer comprehensive digital solutions tailored to meet your unique business needs and drive sustainable growth.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="group bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="w-14 h-14 bg-gradient-to-r from-blue-600 to-teal-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <service.icon className="w-7 h-7 text-white" />
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors duration-300">
                {service.title}
              </h3>
              
              <p className="text-gray-600 mb-6 leading-relaxed">
                {service.description}
              </p>
              
              <div className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center text-sm text-gray-500">
                    <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-3"></div>
                    {feature}
                  </div>
                ))}
              </div>
              
              <button className="mt-6 text-blue-600 font-medium hover:text-blue-700 transition-colors duration-300 group-hover:translate-x-2 transform transition-transform duration-300">
                Learn More →
              </button>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-3xl p-12 text-white">
            <h3 className="text-3xl font-bold mb-4">Ready to Get Started?</h3>
            <p className="text-blue-100 mb-8 text-lg">
              Let's discuss how we can help transform your business with our innovative solutions.
            </p>
            <button className="bg-white text-blue-600 px-8 py-4 rounded-full font-medium hover:shadow-lg transform hover:scale-105 transition-all duration-300">
              Schedule a Consultation
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;